# Book Data

This directory contains the extracted data from nano-graphrag processing.

## Structure
- Raw data files extracted from books
- Processed knowledge graphs
- Entity and relationship mappings

## Data Sources
Data is extracted via nano-graphrag from Google Drive book collection.